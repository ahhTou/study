<template>
</template>

<script>
    import Heart from "../components/Heart"

    export default {
        name: "Login",
        components: {
            Heart
        },
        data() {
            return {}
        },
        methods: {}
    }
</script>

<style lang="scss" scoped>

</style>