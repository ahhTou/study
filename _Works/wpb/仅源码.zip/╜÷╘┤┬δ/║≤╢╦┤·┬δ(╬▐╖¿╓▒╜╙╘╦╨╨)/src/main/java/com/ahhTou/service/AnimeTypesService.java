package com.ahhTou.service;

import java.util.List;

public interface AnimeTypesService {
    List<String> getAllTypes();

}
