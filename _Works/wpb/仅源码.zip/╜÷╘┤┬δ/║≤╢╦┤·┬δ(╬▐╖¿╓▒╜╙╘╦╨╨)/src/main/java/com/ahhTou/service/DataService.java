package com.ahhTou.service;

import com.ahhTou.bean.User;

public interface DataService {

    User getBasicData(String username);

}
